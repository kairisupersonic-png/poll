#!/usr/bin/env bash
set -e
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp -n .env.example .env || true
mkdir -p logs
echo "Installed. Edit .env, then: source venv/bin/activate && python main.py"
