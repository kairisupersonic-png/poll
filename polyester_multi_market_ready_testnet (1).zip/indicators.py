def ema(xs,n):
    if len(xs)<n:return None
    v=sum(xs[:n])/n;k=2/(n+1)
    for x in xs[n:]:v=x*k+v*(1-k)
    return v

def rsi(xs,n=14):
    if len(xs)<n+1:return None
    gains=[];losses=[]
    for a,z in zip(xs,xs[1:]):
        d=z-a;gains.append(max(d,0));losses.append(max(-d,0))
    ag=sum(gains[:n])/n;al=sum(losses[:n])/n
    for j in range(n,len(gains)):
        ag=(ag*(n-1)+gains[j])/n;al=(al*(n-1)+losses[j])/n
    if al==0:return 100.0
    return 100-(100/(1+ag/al))
