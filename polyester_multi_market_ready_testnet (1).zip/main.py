import asyncio, logging, time
from decimal import Decimal, ROUND_DOWN
from uuid import uuid4
from polyester import AsyncPolyester
import config
from indicators import ema,rsi
from telegram import send

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.StreamHandler(),logging.FileHandler("logs/bot.log")]
)

def dec(x):
    try:return Decimal(str(x))
    except:return None

def val(x):
    if x is None:return None
    for a in ("value","ticks","amount"):
        y=getattr(x,a,None)
        if y is not None:
            try:return Decimal(str(y))
            except:pass
    return dec(x)

def raw_symbols(raw):
    out=[]
    def walk(x):
        if isinstance(x,dict):
            sym=x.get("symbol") or x.get("pair_symbol") or x.get("pairSymbol")
            if sym: out.append(str(sym))
            for v in x.values(): walk(v)
        elif isinstance(x,(list,tuple)):
            for v in x: walk(v)
        else:
            for a in ("symbol","pair_symbol","pairSymbol"):
                y=getattr(x,a,None)
                if y: out.append(str(y))
    walk(raw)
    return list(dict.fromkeys(out))

def strategy(closes):
    if len(closes)<max(config.EMA_SLOW+3,config.RSI_PERIOD+3):return False,{}
    ef=ema(closes,config.EMA_FAST); es=ema(closes,config.EMA_SLOW); rr=rsi(closes,config.RSI_PERIOD)
    p=closes[-1]
    ok=ef and es and rr is not None and ef>es and p>ef and config.RSI_MIN<=rr<=config.RSI_MAX
    return bool(ok),{"price":p,"ema_fast":ef,"ema_slow":es,"rsi":rr}

async def candle_closes(client,symbol):
    r=await client.market_data.get_candles(symbol=symbol,timeframe=config.TIMEFRAME,limit=config.CANDLE_LIMIT)
    rows=list(reversed(r.candles))
    return [float(val(getattr(c,"close",None))) for c in rows if val(getattr(c,"close",None)) is not None]

async def best_prices(client,symbol):
    book=await client.orderbook.get(symbol=symbol,depth=1)
    if not book.bids or not book.asks:return None,None
    return val(book.bids[0].price),val(book.asks[0].price)

async def wait_complete(client,order_id,timeout=20):
    fn=getattr(client.orders,"wait_for_order_trades_complete",None)
    if fn:
        try:
            return await fn(order_id=order_id,timeout_sec=timeout)
        except TypeError:
            try:return await fn(order_id,timeout)
            except:pass
        except:pass
    end=time.time()+timeout
    while time.time()<end:
        x=await client.orders.get(order_id=order_id)
        o=getattr(x,"order",None)
        if o and str(getattr(o,"status","")).lower() in ("filled","cancelled","rejected"):
            return x
        await asyncio.sleep(1)
    return await client.orders.get(order_id=order_id)

async def buy(client,symbol):
    bid,ask=await best_prices(client,symbol)
    if ask is None:return None
    if config.DRY_RUN:
        return {"symbol":symbol,"entry":ask,"qty":Decimal(str(config.MAX_POSITION_USDT))/ask,"order_id":"DRY"}
    cid="bot-buy-"+uuid4().hex[:20]
    result=await client.orders.create(
        symbol=symbol,side="buy",order_type="limit",tif="ioc",
        max_quote_debit=str(config.MAX_POSITION_USDT),
        price=str(ask),client_order_id=cid,fee_asset="quote"
    )
    details=await wait_complete(client,result.order_id)
    o=getattr(details,"order",None)
    fills=getattr(details,"trades",[]) or []
    qty=sum((val(getattr(t,"qty",0)) or Decimal("0")) for t in fills)
    avg=sum((val(getattr(t,"price",0)) or Decimal("0"))*(val(getattr(t,"qty",0)) or Decimal("0")) for t in fills)/qty if qty else None
    status=str(getattr(o,"status","")).lower() if o else ""
    if status!="filled" and qty<=0:return None
    return {"symbol":symbol,"entry":avg or ask,"qty":qty,"order_id":result.order_id}

async def sell(client,pos,reason):
    symbol=pos["symbol"];qty=pos["qty"]
    if config.DRY_RUN:
        return True
    cid="bot-sell-"+uuid4().hex[:20]
    result=await client.orders.create(
        symbol=symbol,side="sell",order_type="market",tif="ioc",
        qty=str(qty),client_order_id=cid,fee_asset="quote"
    )
    details=await wait_complete(client,result.order_id)
    o=getattr(details,"order",None)
    return str(getattr(o,"status","")).lower()=="filled"

async def main():
    config.validate()
    async with AsyncPolyester(
        api_key_id=config.API_KEY_ID,
        api_private_key=config.API_PRIVATE_KEY,
        default_account_id=config.ACCOUNT_ID,
        hydrate_catalogs=True
    ) as client:
        await client.wait_for_catalogs()
        send("🤖 Polyester bot started\\nTESTNET=true\\nDRY_RUN="+str(config.DRY_RUN))
        positions={}
        cooldown={}
        overview=await client.market_overview.list(limit=500)
        symbols=[]
        for m in overview.markets:
            s=str(m.symbol)
            if any(s.upper().endswith("-"+q) for q in config.QUOTE_ASSETS):
                symbols.append(s)
        symbols=list(dict.fromkeys(symbols))[:config.MAX_MARKETS]
        logging.info("Markets: %s",symbols)
        send("Markets loaded: "+", ".join(symbols))

        while True:
            now=time.time()
            # Manage existing positions first.
            for symbol,pos in list(positions.items()):
                _,ask=await best_prices(client,symbol)
                px=ask or pos["entry"]
                tp=pos["entry"]*(Decimal("1")+Decimal(str(config.TAKE_PROFIT_PERCENT))/100)
                sl=pos["entry"]*(Decimal("1")-Decimal(str(config.STOP_LOSS_PERCENT))/100)
                if px>=tp or px<=sl:
                    reason="TAKE PROFIT" if px>=tp else "STOP LOSS"
                    ok=await sell(client,pos,reason)
                    if ok:
                        pnl=(px-pos["entry"])*pos["qty"]
                        send(f"🔴 SELL {symbol}\\nReason: {reason}\\nEntry: {pos['entry']:.8f}\\nExit: {px:.8f}\\nPnL: {pnl:.6f}\\nMode: TESTNET")
                        logging.info("SELL %s %s pnl=%s",symbol,reason,pnl)
                        positions.pop(symbol,None);cooldown[symbol]=now
                await asyncio.sleep(0)

            if len(positions)<config.MAX_ACTIVE_POSITIONS:
                for symbol in symbols:
                    if symbol in positions:continue
                    if now-cooldown.get(symbol,0)<config.COOLDOWN_MINUTES*60:continue
                    try:
                        closes=await candle_closes(client,symbol)
                        ok,d=strategy(closes)
                        if ok:
                            pos=await buy(client,symbol)
                            if pos:
                                positions[symbol]=pos
                                send(f"🟢 BUY {symbol}\\nEntry: {pos['entry']:.8f}\\nQty: {pos['qty']}\\nTP: {pos['entry']*(Decimal(1)+Decimal(str(config.TAKE_PROFIT_PERCENT))/100):.8f}\\nSL: {pos['entry']*(Decimal(1)-Decimal(str(config.STOP_LOSS_PERCENT))/100):.8f}\\nMode: TESTNET")
                                logging.info("BUY %s %s",symbol,pos)
                                if len(positions)>=config.MAX_ACTIVE_POSITIONS:break
                    except Exception as e:
                        logging.exception("scan %s failed",symbol)
            await asyncio.sleep(config.POLL_SECONDS)

if __name__=="__main__":
    try: asyncio.run(main())
    except KeyboardInterrupt: logging.info("Stopped")
