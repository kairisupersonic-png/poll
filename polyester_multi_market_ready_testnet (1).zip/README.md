# Polyester Multi-Market Auto Trader (Testnet)

This is a long-only SPOT auto-trader for Polyester Testnet.

Features:
- Discovers current spot markets from Polyester market overview.
- Scans multiple markets.
- Can hold several different coins at once.
- Uses EMA + RSI entry filter.
- BUY -> monitor -> SELL on take-profit or stop-loss.
- Re-scans after a position closes.
- Telegram alerts.
- Restart reconciliation of open orders.
- Testnet only.
- DRY_RUN=true by default.

IMPORTANT:
1. Start with DRY_RUN=true.
2. TESTNET is locked to true in config.py.
3. This is not a profit guarantee.
4. The strategy is long-only spot. No shorting or leverage.
