import requests
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
def send(msg):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:return
    try:
        requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json={"chat_id":TELEGRAM_CHAT_ID,"text":msg},timeout=10
        )
    except Exception as e: print("[telegram]",e)
