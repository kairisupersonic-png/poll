import os
from dotenv import load_dotenv
load_dotenv()

def b(k,d=False): return os.getenv(k,str(d)).lower() in ("1","true","yes","on")
def i(k,d): 
    try: return int(os.getenv(k,d))
    except: return d
def f(k,d):
    try: return float(os.getenv(k,d))
    except: return d

API_KEY_ID=os.getenv("POLYESTER_API_KEY_ID","")
API_PRIVATE_KEY=os.getenv("POLYESTER_API_PRIVATE_KEY","")
ACCOUNT_ID=os.getenv("POLYESTER_ACCOUNT_ID","")
TELEGRAM_BOT_TOKEN=os.getenv("TELEGRAM_BOT_TOKEN","")
TELEGRAM_CHAT_ID=os.getenv("TELEGRAM_CHAT_ID","")

QUOTE_ASSETS=[x.strip().upper() for x in os.getenv("QUOTE_ASSETS","USDT,USDC").split(",") if x.strip()]
MAX_MARKETS=i("MAX_MARKETS",20)
MAX_ACTIVE_POSITIONS=i("MAX_ACTIVE_POSITIONS",3)
TIMEFRAME=os.getenv("TIMEFRAME","5m")
CANDLE_LIMIT=i("CANDLE_LIMIT",120)
EMA_FAST=i("EMA_FAST",20); EMA_SLOW=i("EMA_SLOW",50); RSI_PERIOD=i("RSI_PERIOD",14)
RSI_MIN=f("RSI_MIN",50); RSI_MAX=f("RSI_MAX",70)
MAX_POSITION_USDT=f("MAX_POSITION_USDT",10)
TAKE_PROFIT_PERCENT=f("TAKE_PROFIT_PERCENT",2)
STOP_LOSS_PERCENT=f("STOP_LOSS_PERCENT",1)
COOLDOWN_MINUTES=i("COOLDOWN_MINUTES",15)
POLL_SECONDS=i("POLL_SECONDS",15)
TESTNET=b("TESTNET",True); DRY_RUN=b("DRY_RUN",True)

def validate():
    if not API_KEY_ID or not API_PRIVATE_KEY or not ACCOUNT_ID:
        raise RuntimeError("Fill POLYESTER_API_KEY_ID, POLYESTER_API_PRIVATE_KEY and POLYESTER_ACCOUNT_ID in .env")
    if not TESTNET:
        raise RuntimeError("TESTNET must remain true.")
